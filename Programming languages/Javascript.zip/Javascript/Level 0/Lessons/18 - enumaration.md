Enumeration parsing through each element using a for-each loop, scanning, and going through each element using brute-forcing

refrencing eleememts and getting elements 